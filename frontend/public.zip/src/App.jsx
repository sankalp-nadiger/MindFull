import React from "react"
import {BrowserRouter as Router,Routes,Route} from "react-router-dom"
import './App.css'
import HomePage from './components/HomePage/HomePage'
import ParentDashboard from "./components/ParentPage/ParentPage"
import { HeroHighlightDemo } from "./components/MainPage/mainPage"
import Activity from "./components/Activities/activity"
import Councellor from "./components/Councellor/councellor"
import CommunityChat from "./components/Community/Communitychat"
import Quiz from "./components/Games/quizgame"
import SudokuGame from "./components/Games/sudoku"
import CrosswordGame from "./components/Games/Crosswords"
import Leaderboard from "./components/Badges and Leaderboard/Leaderboard"
function App() {

  return (
    <>
      <Router>
        <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/ParentDashboard" element={<ParentDashboard />} />
        <Route path="/MainPage" element={<HeroHighlightDemo />} />
        <Route path="/Activities" element={<Activity />} />
        <Route path="/councellor" element={<Councellor />} />
        <Route path="/communitychat" element={<CommunityChat />} />
        <Route path="/Quiz" element={<Quiz/>} />
        <Route path="/SudokuGame" element={<SudokuGame/>} />
        <Route path="/Crossword" element={<CrosswordGame/>} />
        <Route path="/Leaderboard" element={<Leaderboard/>} />

        </Routes>
      </Router>
    </>
  )
}

export default App
