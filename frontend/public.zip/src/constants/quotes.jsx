
  export default quotes;