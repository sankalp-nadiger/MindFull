import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
 // Assuming you have a CSS file for styling

function CommunityChat () {
  const [socket, setSocket] = useState(null);
  const [roomId, setRoomId] = useState('');
  const [userId, setUserId] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const newSocket = io('http://localhost:3000');
    setSocket(newSocket);
    newSocket.on('user-joined', (data) => {
      setMessages((prev) => [...prev, { system: true, message: `${data.userId} joined the room.` }]);
    });
    newSocket.on('community-message', (data) => {
      setMessages((prev) => [...prev, { userId: data.userId, message: data.message }]);
    });
    return () => {
      newSocket.disconnect();
    };
  }, []);

  const joinRoom = async () => {
    if (!roomId || !userId) {
      alert('User ID and Room ID are required');
      return;
    }
    socket.emit('join-room', roomId);
    try {
      const response = await fetch('http://localhost:3000/api/community/join-room', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, roomId }),
      });
      const data = await response.json();
      if (response.ok) {
        console.log(data.message);
        setIsConnected(true);
      } else {
        alert(data.error || 'Failed to join room');
      }
    } catch (err) {
      console.error('Error joining room:', err);
    }
  };

  const sendMessage = async () => {
    if (!roomId || !userId || !message) {
      alert('All fields are required');
      return;
    }
    socket.emit('send-message', { message, roomId });
    try {
      const response = await fetch('http://localhost:3000/api/community/send-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId, message }),
      });
      const data = await response.json();
      if (response.ok) {
        setMessage('');
      } else {
        alert(data.error || 'Failed to send message');
      }
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  return (
    <div className="chat-container">
      <h1>Community Chat</h1>
      {!isConnected ? (
        <div className="join-form">
          <input
            type="text"
            placeholder="Enter Room ID"
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
          />
          <input
            type="text"
            placeholder="Enter Your User ID"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
          <button onClick={joinRoom}>Join Room</button>
        </div>
      ) : (
        <div className="chat-window">
          <h2>Room: {roomId}</h2>
          <div className="messages">
            {messages.map((msg, index) =>
              msg.system ? (
                <div key={index} className="system-message">
                  {msg.message}
                </div>
              ) : (
                <div key={index} className="user-message">
                  <strong>{msg.userId}: </strong> {msg.message}
                </div>
              )
            )}
          </div>
          <input
            type="text"
            placeholder="Type your message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          <button onClick={sendMessage}>Send</button>
        </div>
      )}
    </div>
  );
};

export default CommunityChat;