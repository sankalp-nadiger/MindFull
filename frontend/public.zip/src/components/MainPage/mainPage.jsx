"use client";
import { motion } from "framer-motion";
import { useState,useEffect } from "react";
import { HeroHighlight, Highlight } from "./HeroHighlight"
import Navbar from "../Navbar/Navbar";
import { ChatInterface } from "../ChatBot/ChatInterface";
import { useNavigate } from 'react-router-dom';
import { Bot } from 'lucide-react';
import { BentoGridDemo } from "./BentoGridDemo";
import Getquotes from "./quotes";
import BadgesCorner from "../Badges and Leaderboard/Badges";
export function HeroHighlightDemo() {
  const navigate = useNavigate(); // Initialize useNavigate hook

  // Button click handler
  const handleactivity = () => {
    navigate('/Activities'); // Navigate to the desired page (adjust path as needed)
  };

  const handlebot=()=>{
    window.location.href = 'https://fda5defddbb8db552a.gradio.live/';
  }


  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

 
  useEffect(() => {
    const fetchUsername = async () => {
      try {
    
        const response = await fetch('http://localhost:3000/api/user/current');


        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

    
        const data = await response.json();

    
        setUsername(data.username);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsername();
  }, []); 

  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <>
    
    <Navbar/>
    <div style={{height:"70%",width:"100%"}}>
    <HeroHighlight>
      <motion.h1
        initial={{
          opacity: 0,
          y: 20,
        }}
        animate={{
          opacity: 1,
          y: [20, -5, 0],
        }}
        transition={{
          duration: 0.5,
          ease: [0.4, 0.0, 0.2, 1],
        }}
        className=" flex flex-wrap top-0 align-top justify-center text-2xl px-0 md:text-5xl lg:text-8xl font-bold text-neutral-700 dark:text-white max-w-4xl leading-relaxed lg:leading-snug text-center mx-auto "
      >
        Welcome,
        <Highlight className=" text-black dark:text-white px-2">
       {/* {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      {!loading && !error && (
         {username}
      )} */}
      Sujith Kumar
        </Highlight>
        <div className="  block text-2xl px-4 md:text-4xl lg:text-5xl">How's Your Day Today ?</div>
      </motion.h1>
    </HeroHighlight>
    </div>

    <div className="bg-gray-200">
       <Getquotes/> 
    </div>
    <div className="bg-black">
    <BentoGridDemo/>
    </div>
    <section class="text-white bg-black body-font">
  <div class="container px-3 py-24 mx-auto">
    <div class="lg:w-2/3 flex flex-col sm:flex-row sm:items-center items-start mx-auto w-full">
      <h1 class="flex-grow sm:pr-16 text-5xl font-medium title-font text-white">Activity Recommendations Curated for YOU .....</h1>
      <button onClick={handleactivity} className="flex-shrink-0 text-black bg-green-600 border-0 py-2 px-8 focus:outline-none hover:bg-green-800 rounded text-lg mt-10 sm:mt-0">See Activities</button>
    </div>
  </div>
  <div className="max-w-3xl mx-auto bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 rounded-lg shadow-lg p-6 ">
      {/* Card Header with Text */}
      <h3 className="text-7xl font-semibold text-black mb-4">EVENTS</h3>

      
      {/* Card Content (Can be added later) */}
      <p className="text-amber-950 mb-6">Check out upcoming events and happenings!</p>
      
      {/* Button */}
      <button className="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300">
        View More
      </button>
    </div>
    <BadgesCorner/>
</section>
     {/* Chat interface */}
     {isChatOpen && (
        <div className="fixed bottom-24 right-8 w-[400px] h-[400px] z-50">
          <ChatInterface />
        </div>
      )}

     

    </>
  );
}
